# n8n Pre-entrega – Lead Enrichment + Telegram Notifications

- **Trigger:** Google Sheets Trigger (**New Row Added**) starts the workflow on each inserted lead row.
- **Normalization:** Set node normalizes fields (e.g., `email.toLowerCase().trim()`), adds `timestamp`, and maps a consistent payload.
- **API integration:** HTTP Request calls a public no-auth API (`https://catfact.ninja/fact`) to enrich the execution context.
- **Derived metric:** A numeric `age`-like field is computed from API output (e.g., `length`) to demonstrate conditional routing.
- **Conditional routing:** Switch node evaluates the numeric field and routes to Segment **A (>=30)**, **B (<30)**, or **C (empty/fallback)**.
- **Notifications:** Telegram nodes send branch-specific messages using expressions; **chatId is redacted** in this export.
- **Persistence:** Google Sheets Update Row writes back `age`, `segment`, `timestamp`, and `status` to the original row.
- **Idempotency:** Persisted `status` supports basic re-run control (avoids double-processing when used as a guard).
- **Security/Compliance:** No real credentials are included; credential references are kept for n8n’s credential store resolution.
